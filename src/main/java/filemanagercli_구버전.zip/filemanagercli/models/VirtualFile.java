package filemanagercli.models;

public class VirtualFile {
    private final String path;
    private final boolean isDirectory;

    public VirtualFile(String path, boolean isDirectory) {
        this.path = path;
        this.isDirectory = isDirectory;
    }

    public String getPath() {
        return path;
    }

    public boolean isDirectory() {
        return isDirectory;
    }

    @Override
    public String toString() {
        return (isDirectory ? "[DIR] " : "[FILE] ") + path;
    }
}

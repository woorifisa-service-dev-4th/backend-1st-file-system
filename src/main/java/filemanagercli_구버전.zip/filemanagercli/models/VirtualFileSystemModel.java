package filemanagercli.models;

import java.util.HashMap;
import java.util.Map;

public class VirtualFileSystemModel {
    private final Map<String, VirtualFile> files;

    public VirtualFileSystemModel() {
        files = new HashMap<>();
    }

    public void addFile(String path, boolean isDirectory) {
        files.put(path, isDirectory ? new VirtualDirectory(path) : new VirtualFile(path, false));
    }

    public VirtualFile getFile(String path) {
        return files.get(path);
    }

    public boolean exists(String path) {
        return files.containsKey(path);
    }

    public void deleteFile(String path) {
        files.remove(path);
    }

    public Map<String, VirtualFile> getFiles() {
        return files;
    }
}

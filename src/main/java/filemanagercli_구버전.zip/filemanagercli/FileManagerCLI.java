package filemanagercli;

import filemanagercli.commands.*;
import org.jline.reader.LineReader;
import org.jline.reader.LineReaderBuilder;
import org.jline.terminal.Terminal;
import org.jline.terminal.TerminalBuilder;

import java.io.IOException;

public class FileManagerCLI {

    private final VirtualFileSystem vfs;

    public FileManagerCLI() {
        this.vfs = new VirtualFileSystem();
    }

    public void start() {
        try {
            Terminal terminal = TerminalBuilder.builder().system(true).build();
            LineReader reader = LineReaderBuilder.builder().terminal(terminal).build();

            while (true) {
                String command = reader.readLine("> ");
                if (command.equals("exit")) break;

                handleCommand(command);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handleCommand(String command) {
        String[] parts = command.split(" ");
        String cmd = parts[0];

        switch (cmd) {
            case "ls":
                new LsCommand(vfs).execute(parts);
                break;
            default:
                System.out.println("Unknown command: " + cmd);
        }
    }

    public static void main(String[] args) {
        new FileManagerCLI().start();
    }
}

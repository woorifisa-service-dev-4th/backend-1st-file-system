package filemanagercli;

import filemanagercli.models.VirtualFile;
import java.util.*;

public class VirtualFileSystem {
    private Map<String, VirtualFile> files;
    private String currentPath = "/empty_project";
    private Map<String, String> fileOwners;
    private Map<String, String> fileGroups;
    private Map<String, String> filePermissions;

    public VirtualFileSystem() {
        files = new HashMap<>();
        initializeDummyData();
    }

    private void initializeDummyData() {
        addFile("/empty_project", true);
        addFile("/empty_project/data", true);
        addFile("/empty_project/data/raw_data.csv", false);
        addFile("/empty_project/data/processed_data.json", false);
        addFile("/empty_project/data/config.yaml", false);
        addFile("/empty_project/src", true);
        addFile("/empty_project/src/main.py", false);
        addFile("/empty_project/src/helper.py", false);
        addFile("/empty_project/src/analyzer.py", false);
        addFile("/empty_project/src/processor.py", false);
        addFile("/empty_project/logs", true);
        addFile("/empty_project/logs/app.log", false);
        addFile("/empty_project/logs/error.log", false);
        addFile("/empty_project/docs", true);
        addFile("/empty_project/docs/README.md", false);
        addFile("/empty_project/docs/requirements.txt", false);
        addFile("/empty_project/docs/changelog.md", false);
        addFile("/empty_project/tests", true);
        addFile("/empty_project/tests/test_main.py", false);
        addFile("/empty_project/tests/test_helper.py", false);
        addFile("/empty_project/tests/test_analyzer.py", false);
        addFile("/empty_project/scripts", true);
        addFile("/empty_project/scripts/setup.sh", false);
        addFile("/empty_project/scripts/run.sh", false);
        addFile("/empty_project/scripts/clean.sh", false);
    }

    public void addFile(String path, boolean isDirectory) {
        files.put(path, new VirtualFile(path, isDirectory));
        fileOwners.put(path, "root");
        fileGroups.put(path, "root");
        filePermissions.put(path, "rw-r--r--");
    }

    public List<String> listFiles(String directory) {
        List<String> result = new ArrayList<>();
        for (String path : files.keySet()) {
            if (path.startsWith(directory) && !path.equals(directory)) {
                result.add(path.replace(directory + "/", ""));
            }
        }
        return result;
    }

    public void changePermissions(String path, String permissions) {
        if (!files.containsKey(path)) {
            System.out.println("Error: File not found.");
            return;
        }
        filePermissions.put(path, permissions);
        System.out.println("Permissions changed for " + path + " to " + permissions);
    }

    public void changeOwner(String path, String owner) {
        if (!files.containsKey(path)) {
            System.out.println("Error: File not found.");
            return;
        }
        fileOwners.put(path, owner);
        System.out.println("Owner changed for " + path + " to " + owner);
    }

    public void changeGroup(String path, String group) {
        if (!files.containsKey(path)) {
            System.out.println("Error: File not found.");
            return;
        }
        fileGroups.put(path, group);
        System.out.println("Group changed for " + path + " to " + group);
    }

    public List<String> findFiles(String keyword) {
        List<String> foundFiles = new ArrayList<>();
        for (String path : files.keySet()) {
            if (path.contains(keyword)) {
                foundFiles.add(path);
            }
        }
        return foundFiles;
    }

    public void grep(String keyword, String filePath) {
        if (!files.containsKey(filePath) || files.get(filePath).isDirectory()) {
            System.out.println("Error: File not found or is a directory.");
            return;
        }
        System.out.println("Searching for \"" + keyword + "\" in " + filePath + "...");
    }

    public String getCurrentPath() {
        return currentPath;
    }

    public void removeDirectory(String path) {
        if (!files.containsKey(path)) {
            System.out.println("Error: Directory not found.");
            return;
        }

        VirtualFile file = files.get(path);

        if (!file.isDirectory()) {
            System.out.println("Error: Not a directory.");
            return;
        }

        for (String key : files.keySet()) {
            if (key.startsWith(path + "/")) {
                System.out.println("Error: Directory is not empty.");
                return;
            }
        }

        files.remove(path);
        System.out.println("Deleted directory: " + path);
    }


    public void moveFile(String source, String destination) {
        if (!files.containsKey(source)) {
            System.out.println("Error: Source file not found.");
            return;
        }
        VirtualFile file = files.remove(source);
        files.put(destination, file);
        System.out.println("Moved: " + source + " → " + destination);
    }

    public void copyFile(String source, String destination) {
        if (!files.containsKey(source)) {
            System.out.println("Error: Source file not found.");
            return;
        }
        VirtualFile original = files.get(source);
        files.put(destination, new VirtualFile(destination, original.isDirectory()));
        System.out.println("Copied: " + source + " → " + destination);
    }

    public void deleteFile(String path) {
        if (!files.containsKey(path)) {
            System.out.println("Error: File not found.");
            return;
        }
        files.remove(path);
        System.out.println("Deleted: " + path);
    }

    public void createDirectory(String path) {
        if (files.containsKey(path)) {
            System.out.println("Error: Directory already exists.");
            return;
        }
        files.put(path, new VirtualFile(path, true));
        System.out.println("Created directory: " + path);
    }

    public void createFile(String path) {
        if (files.containsKey(path)) {
            System.out.println("Error: File already exists.");
            return;
        }
        files.put(path, new VirtualFile(path, false));
        System.out.println("Created file: " + path);
    }

    public void readFile(String path) {
        if (!files.containsKey(path)) {
            System.out.println("Error: File not found.");
            return;
        }
        if (files.get(path).isDirectory()) {
            System.out.println("Error: Cannot read a directory.");
            return;
        }
        System.out.println("Reading file: " + path);
    }
}

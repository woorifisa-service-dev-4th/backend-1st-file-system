package filemanagercli.exceptions;

public class CommandException extends Exception {
    public CommandException(String message) {
        super(message);
    }
}

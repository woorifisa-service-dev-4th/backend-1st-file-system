package filemanagercli.commands;

import filemanagercli.VirtualFileSystem;
import java.util.List;

public class LsCommand {
    private final VirtualFileSystem vfs;

    public LsCommand(VirtualFileSystem vfs) {
        this.vfs = vfs;
    }

    public void execute(String[] args) {
        String currentPath = vfs.getCurrentPath();
        List<String> files = vfs.listFiles(currentPath);
        for (String file : files) {
            System.out.println(file);
        }
    }
}

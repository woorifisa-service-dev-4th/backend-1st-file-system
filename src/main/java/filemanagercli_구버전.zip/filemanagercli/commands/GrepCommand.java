package filemanagercli.commands;

import filemanagercli.VirtualFileSystem;

public class GrepCommand {
    private final VirtualFileSystem vfs;

    public GrepCommand(VirtualFileSystem vfs) {
        this.vfs = vfs;
    }

    public void execute(String[] args) {
        if (args.length < 3) {
            System.out.println("Usage: grep <keyword> <file>");
            return;
        }
        vfs.grep(args[1], args[2]);
    }
}

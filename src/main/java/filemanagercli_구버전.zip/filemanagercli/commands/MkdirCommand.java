package filemanagercli.commands;

import filemanagercli.VirtualFileSystem;

public class MkdirCommand {
    private final VirtualFileSystem vfs;

    public MkdirCommand(VirtualFileSystem vfs) {
        this.vfs = vfs;
    }

    public void execute(String[] args) {
        if (args.length < 2) {
            System.out.println("Usage: mkdir <directory>");
            return;
        }
        vfs.createDirectory(args[1]);
    }
}

package filemanagercli.commands;

import filemanagercli.VirtualFileSystem;

public class MvCommand {
    private final VirtualFileSystem vfs;

    public MvCommand(VirtualFileSystem vfs) {
        this.vfs = vfs;
    }

    public void execute(String[] args) {
        if (args.length < 3) {
            System.out.println("Usage: mv <source> <destination>");
            return;
        }
        vfs.moveFile(args[1], args[2]);
    }
}

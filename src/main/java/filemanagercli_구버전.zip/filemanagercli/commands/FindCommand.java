package filemanagercli.commands;

import filemanagercli.VirtualFileSystem;
import java.util.List;

public class FindCommand {
    private final VirtualFileSystem vfs;

    public FindCommand(VirtualFileSystem vfs) {
        this.vfs = vfs;
    }

    public void execute(String[] args) {
        if (args.length < 2) {
            System.out.println("Usage: find <keyword>");
            return;
        }
        List<String> results = vfs.findFiles(args[1]);
        if (results.isEmpty()) {
            System.out.println("No files found matching: " + args[1]);
        } else {
            results.forEach(System.out::println);
        }
    }
}

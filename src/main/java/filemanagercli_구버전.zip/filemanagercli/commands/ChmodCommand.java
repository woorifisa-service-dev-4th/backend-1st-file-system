package filemanagercli.commands;

import filemanagercli.VirtualFileSystem;

public class ChmodCommand {
    private final VirtualFileSystem vfs;

    public ChmodCommand(VirtualFileSystem vfs) {
        this.vfs = vfs;
    }

    public void execute(String[] args) {
        if (args.length < 3) {
            System.out.println("Usage: chmod <permissions> <file>");
            return;
        }
        vfs.changePermissions(args[2], args[1]);
    }
}

package filemanagercli.commands;

public class ExitCommand {
    public void execute(String[] args) {
        System.out.println("Exiting file manager...");
        System.exit(0);
    }
}

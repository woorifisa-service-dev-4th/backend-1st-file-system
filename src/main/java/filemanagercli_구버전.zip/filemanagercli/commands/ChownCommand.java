package filemanagercli.commands;

import filemanagercli.VirtualFileSystem;

public class ChownCommand {
    private final VirtualFileSystem vfs;

    public ChownCommand(VirtualFileSystem vfs) {
        this.vfs = vfs;
    }

    public void execute(String[] args) {
        if (args.length < 3) {
            System.out.println("Usage: chown <owner> <file>");
            return;
        }
        vfs.changeOwner(args[2], args[1]);
    }
}

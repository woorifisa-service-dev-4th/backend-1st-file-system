package filemanagercli.commands;

import filemanagercli.VirtualFileSystem;

public class RmdirCommand {
    private final VirtualFileSystem vfs;

    public RmdirCommand(VirtualFileSystem vfs) {
        this.vfs = vfs;
    }

    public void execute(String[] args) {
        if (args.length < 2) {
            System.out.println("Usage: rmdir <directory>");
            return;
        }
        vfs.removeDirectory(args[1]);
    }
}

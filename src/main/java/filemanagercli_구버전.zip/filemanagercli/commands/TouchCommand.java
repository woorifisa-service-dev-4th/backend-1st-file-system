package filemanagercli.commands;

import filemanagercli.VirtualFileSystem;

public class TouchCommand {
    private final VirtualFileSystem vfs;

    public TouchCommand(VirtualFileSystem vfs) {
        this.vfs = vfs;
    }

    public void execute(String[] args) {
        if (args.length < 2) {
            System.out.println("Usage: touch <file>");
            return;
        }
        vfs.createFile(args[1]);
    }
}

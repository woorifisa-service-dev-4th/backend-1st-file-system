package filemanagercli.commands;

import filemanagercli.VirtualFileSystem;

public class CpCommand {
    private final VirtualFileSystem vfs;

    public CpCommand(VirtualFileSystem vfs) {
        this.vfs = vfs;
    }

    public void execute(String[] args) {
        if (args.length < 3) {
            System.out.println("Usage: cp <source> <destination>");
            return;
        }
        vfs.copyFile(args[1], args[2]);
    }
}

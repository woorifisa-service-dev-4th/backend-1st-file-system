package filemanagercli.commands;

import filemanagercli.VirtualFileSystem;
import java.nio.file.Files;
import java.nio.file.Paths;

public class CatCommand {
    private final VirtualFileSystem vfs;

    public CatCommand(VirtualFileSystem vfs) {
        this.vfs = vfs;
    }

    public void execute(String[] args) {
        if (args.length < 2) {
            System.out.println("Usage: cat <file>");
            return;
        }
        try {
            System.out.println(Files.readString(Paths.get(args[1])));
        } catch (Exception e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }
}

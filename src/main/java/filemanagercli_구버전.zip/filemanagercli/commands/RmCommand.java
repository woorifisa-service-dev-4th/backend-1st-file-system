package filemanagercli.commands;

import filemanagercli.VirtualFileSystem;

public class RmCommand {
    private final VirtualFileSystem vfs;

    public RmCommand(VirtualFileSystem vfs) {
        this.vfs = vfs;
    }

    public void execute(String[] args) {
        if (args.length < 2) {
            System.out.println("Usage: rm <file>");
            return;
        }
        vfs.deleteFile(args[1]);
    }
}

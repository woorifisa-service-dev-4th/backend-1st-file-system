package filemanagercli.commands;

import filemanagercli.VirtualFileSystem;

public class ChgrpCommand {
    private final VirtualFileSystem vfs;

    public ChgrpCommand(VirtualFileSystem vfs) {
        this.vfs = vfs;
    }

    public void execute(String[] args) {
        if (args.length < 3) {
            System.out.println("Usage: chgrp <group> <file>");
            return;
        }
        vfs.changeGroup(args[2], args[1]);
    }
}

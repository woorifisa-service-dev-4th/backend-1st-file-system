package filemanagercli;

public class App {
    public static void main(String[] args) {
        FileManagerCLI cli = new FileManagerCLI();
        cli.start();
    }
}
